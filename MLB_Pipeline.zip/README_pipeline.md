# 🧬 Module J — `pipeline.py`

## 🎯 Purpose
The `pipeline.py` orchestrator is the final module in the MLB Player-Performance Prediction pipeline. It coordinates the execution of Modules A → L based on CLI arguments, config settings, and concurrency rules.

## ⚙️ Config Keys & CLI Flags

| CLI Flag                     | Description                                      |
|-----------------------------|--------------------------------------------------|
| `--config-path <file>`      | Load config from file (default: `config.yaml`)  |
| `--overwrite-policy`        | One-off overwrite control: `force`, `warn`, `error` |
| `--set key=value`           | Dotted CLI overrides (repeatable)               |
| `--modules A,B,...`         | Restrict pipeline to selected modules           |
| `--start-from X`            | Start execution at module X                     |
| `--stop-after Y`            | Stop after module Y                             |
| `--concurrency <N>`         | Run modules with up to N parallel workers       |
| `--continue-on-failure`     | Do not halt on first failure                    |
| `--dry-run`                 | Log execution plan only                         |
| `--debug`                   | Emit debug prints if enabled                    |

## 🧾 Logger Behavior
- Creates rotating log file: `logs/pipeline_<timestamp>.log`
- Logs:
  - Config path, CLI args
  - Module start and stop
  - Duration per module
  - Failures with traceback or subprocess exit codes

## 🔁 Module Execution Sequence
- Default: `A` → `B` → `C` → ... → `L`
- Respects CLI overrides: `--modules`, `--start-from`, `--stop-after`

## 🧵 Concurrency Notes
- Uses `ThreadPoolExecutor` if `--concurrency > 1`
- Independent modules may execute in parallel
- Ordered execution otherwise

## 🧪 Output Summary
- No new datasets written
- Produces summary table in console and log:
  ```
  📊 Pipeline Summary:
   - Module A: SUCCESS
   - Module B: SKIPPED
   - Module C: FAILED
  ```
- Optional: write to `pipeline_summary_<timestamp>.json`

## 🚀 Example Run
```bash
python pipeline.py \
  --config-path config/prod.yaml \
  --modules A,B,C,D,E,F,G,H,K,L \
  --concurrency 4 \
  --continue-on-failure \
  --overwrite-policy warn
```

---

### ✅ Final Validation
- [x] CLI and config parsing
- [x] Overwrite/skip logic enforced
- [x] Module import + subprocess fallback
- [x] Dry-run respected
- [x] Logger operational
- [x] Concurrency supported
- [x] Summary printed/logged
- [x] Unit tests for all edge cases
